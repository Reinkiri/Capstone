package com.pasteleria.cakeapi.service;

import com.google.firebase.messaging.AndroidConfig;
import com.google.firebase.messaging.AndroidNotification;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import org.springframework.stereotype.Service;

@Service
public class FirebaseMessagingService {

    public void enviarNotificacion(String fcmToken, String titulo, String cuerpo) {
        if (fcmToken == null || fcmToken.trim().isEmpty()) {
            System.out.println("El usuario no tiene un token de FCM registrado.");
            return;
        }

        try {
            // Notificación genérica
            Notification notification = Notification.builder()
                    .setTitle(titulo)
                    .setBody(cuerpo)
                    .build();

            // Configuración específica de Android para asignar el icono drawable
            AndroidConfig androidConfig = AndroidConfig.builder()
                    .setNotification(AndroidNotification.builder()
                            .setIcon("ic_notification_cake") // Nombre de la imagen en res/drawable sin la extensión .png
                            .build())
                    .build();

            Message message = Message.builder()
                    .setToken(fcmToken)
                    .setNotification(notification)
                    .setAndroidConfig(androidConfig)
                    .build();

            String response = FirebaseMessaging.getInstance().send(message);
            System.out.println("Notificación enviada con éxito. Respuesta FCM ID: " + response);
        } catch (Exception e) {
            System.err.println("Error al enviar la notificación FCM: " + e.getMessage());
            e.printStackTrace();
        }
    }
}