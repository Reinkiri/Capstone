package com.pasteleria.cakeapi.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FcmTokenDTO {
    private String fcmToken;
}