package com.pasteleria.cakeapi.controllers;

import com.pasteleria.cakeapi.entities.Pedido;
import com.pasteleria.cakeapi.entities.Torta;
import com.pasteleria.cakeapi.entities.Usuario;
import com.pasteleria.cakeapi.repositories.PedidoRepository;
import com.pasteleria.cakeapi.repositories.TortaRepository;
import com.pasteleria.cakeapi.repositories.UsuarioRepository;
import com.pasteleria.cakeapi.service.FirebaseMessagingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pedidos")
@CrossOrigin(origins = "*")
public class PedidoController {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private TortaRepository tortaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private FirebaseMessagingService firebaseMessagingService;

    @GetMapping
    public List<Pedido> listarPedidos() {
        return pedidoRepository.findAll();
    }

    @GetMapping("/mes")
    public List<LocalDate> obtenerFechasOcupadas(
            @RequestParam int anio,
            @RequestParam int mes) {
        return pedidoRepository.findFechasOcupadasDelMes(anio, mes);
    }

    @GetMapping("/fecha/{fecha}")
    public ResponseEntity<List<Pedido>> obtenerPorFecha(@PathVariable String fecha) {
        LocalDate fechaParseada = LocalDate.parse(fecha);
        return ResponseEntity.ok(pedidoRepository.findByFechaEntrega(fechaParseada));
    }

    @GetMapping("/escanear/{codigo}")
    public ResponseEntity<?> buscarPorCodigo(@PathVariable String codigo) {
        if (codigo.toUpperCase().startsWith("PED-")) {
            return pedidoRepository.findByCodigoBarrasPedido(codigo.toUpperCase())
                    .map(pedido -> {
                        if ("PAGADO".equals(pedido.getEstado())) {
                            return ResponseEntity.badRequest().body("Este pedido ya fue pagado.");
                        }
                        Map<String, Object> response = new HashMap<>();
                        response.put("nombre", (pedido.getTorta() != null ? pedido.getTorta().getNombre() : "Pedido") + " (SALDO)");
                        response.put("precio", pedido.getSaldoPendiente());
                        response.put("codigo", pedido.getCodigoBarrasPedido());
                        return ResponseEntity.ok(response);
                    })
                    .orElse(ResponseEntity.notFound().build());
        }

        return tortaRepository.findByCodigoBarrasBase(codigo)
                .map(torta -> {
                    Map<String, Object> response = new HashMap<>();
                    response.put("nombre", torta.getNombre());
                    Double precioBase = (torta.getTamanos() != null && !torta.getTamanos().isEmpty())
                            ? torta.getTamanos().get(0).getPrecio() : 0.0;
                    response.put("precio", precioBase);
                    response.put("codigo", torta.getCodigoBarrasBase());
                    return ResponseEntity.ok(response);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Pedido agendarPedido(@RequestBody Pedido pedido) {
        if (pedido.getEstado() == null) {
            pedido.setEstado("PENDIENTE");
        }

        Pedido pedidoGuardado = pedidoRepository.save(pedido);

        if (pedidoGuardado.getCodigoBarrasPedido() == null || pedidoGuardado.getCodigoBarrasPedido().isEmpty()) {
            pedidoGuardado.setCodigoBarrasPedido("PED-" + pedidoGuardado.getId());
            pedidoGuardado = pedidoRepository.save(pedidoGuardado);
        }

        // NOTIFICACIÓN PUSH A TODOS LOS USUARIOS ADMIN
        try {
            List<Usuario> admins = usuarioRepository.findByRolAndFcmTokenIsNotNullAndFcmTokenNot("ADMIN", "");

            String nombreTorta = "Pedido Especial";

            if (pedidoGuardado.getTorta() != null) {
                if (pedidoGuardado.getTorta().getNombre() != null && !pedidoGuardado.getTorta().getNombre().trim().isEmpty()) {
                    nombreTorta = pedidoGuardado.getTorta().getNombre();
                } else if (pedidoGuardado.getTorta().getId() != null) {
                    nombreTorta = tortaRepository.findById(pedidoGuardado.getTorta().getId())
                            .map(Torta::getNombre)
                            .orElse("Pedido Especial");
                }
            }

            String fechaEntrega = (pedidoGuardado.getFechaEntrega() != null)
                    ? pedidoGuardado.getFechaEntrega().toString()
                    : "Sin fecha definida";

            String mensaje = nombreTorta + " - " + fechaEntrega;

            for (Usuario admin : admins) {
                firebaseMessagingService.enviarNotificacion(
                        admin.getFcmToken(),
                        "Nuevo Pedido!",
                        mensaje
                );
            }
        } catch (Exception e) {
            System.err.println("Error al enviar notificaciones a los administradores: " + e.getMessage());
        }

        return pedidoGuardado;
    }

    @PatchMapping("/{id}/estado")
    public ResponseEntity<?> cambiarEstadoPedido(@PathVariable Long id, @RequestParam String nuevoEstado) {
        return pedidoRepository.findById(id).map(pedido -> {
            pedido.setEstado(nuevoEstado.toUpperCase());
            pedidoRepository.save(pedido);
            return ResponseEntity.ok(Map.of("mensaje", "Estado actualizado correctamente"));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public void eliminarPedido(@PathVariable Long id) {
        pedidoRepository.deleteById(id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pedido> actualizarPedido(@PathVariable Long id, @RequestBody Pedido pedidoActualizado) {
        return pedidoRepository.findById(id).map(pedido -> {
            // Campos básicos
            pedido.setNombreCliente(pedidoActualizado.getNombreCliente());
            pedido.setTelefono(pedidoActualizado.getTelefono());
            pedido.setNotas(pedidoActualizado.getNotas());
            pedido.setFechaEntrega(pedidoActualizado.getFechaEntrega());
            pedido.setBloqueHorario(pedidoActualizado.getBloqueHorario());
            pedido.setDetalleTamano(pedidoActualizado.getDetalleTamano());
            pedido.setTipoCobertura(pedidoActualizado.getTipoCobertura());
            pedido.setCantidad(pedidoActualizado.getCantidad());

            // Actualización de montos y recalculo automático de saldos
            pedido.setPrecioTotal(pedidoActualizado.getPrecioTotal());
            pedido.setMontoAbonado(pedidoActualizado.getMontoAbonado());

            if (pedidoActualizado.getEstado() != null) {
                pedido.setEstado(pedidoActualizado.getEstado());
            }

            // Manejo seguro de la relación Torta
            if (pedidoActualizado.getTorta() != null && pedidoActualizado.getTorta().getId() != null) {
                tortaRepository.findById(pedidoActualizado.getTorta().getId())
                        .ifPresent(pedido::setTorta);
            }

            // Guardar cambios ejecutando @PreUpdate (recalcula saldoPendiente automáticamente)
            Pedido guardado = pedidoRepository.save(pedido);
            return ResponseEntity.ok(guardado);
        }).orElse(ResponseEntity.notFound().build());
    }
}