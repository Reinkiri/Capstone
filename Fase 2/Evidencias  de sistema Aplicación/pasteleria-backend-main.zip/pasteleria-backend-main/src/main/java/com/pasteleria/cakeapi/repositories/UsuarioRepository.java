package com.pasteleria.cakeapi.repositories;

import com.pasteleria.cakeapi.entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    // Buscar al empleado por su nombre al hacer login
    Optional<Usuario> findByUsername(String username);

    // Buscar todos los usuarios por ROL que tengan un token FCM registrado
    List<Usuario> findByRolAndFcmTokenIsNotNullAndFcmTokenNot(String rol, String emptyToken);
}