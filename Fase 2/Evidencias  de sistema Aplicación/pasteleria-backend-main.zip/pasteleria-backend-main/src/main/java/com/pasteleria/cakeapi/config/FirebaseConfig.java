package com.pasteleria.cakeapi.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions; // 👈 Asegúrate de que esta línea esté aquí
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@Configuration
public class FirebaseConfig {

    @PostConstruct
    public void init() {
        try {
            if (!FirebaseApp.getApps().isEmpty()) {
                return;
            }

            InputStream serviceAccount;
            String firebaseConfigEnv = System.getenv("FIREBASE_CONFIG_JSON");

            // Si existe la variable en Railway, la usa. Si no, lee el archivo local.
            if (firebaseConfigEnv != null && !firebaseConfigEnv.isBlank()) {
                serviceAccount = new ByteArrayInputStream(firebaseConfigEnv.getBytes(StandardCharsets.UTF_8));
            } else {
                serviceAccount = getClass().getClassLoader().getResourceAsStream("firebase-key.json");
            }

            if (serviceAccount == null) {
                System.err.println("❌ No se encontró la configuración de Firebase.");
                return;
            }

            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .build();

            FirebaseApp.initializeApp(options);
            System.out.println("✅ Firebase se ha inicializado correctamente.");

        } catch (Exception e) {
            System.err.println("❌ Error al inicializar Firebase: " + e.getMessage());
        }
    }
}