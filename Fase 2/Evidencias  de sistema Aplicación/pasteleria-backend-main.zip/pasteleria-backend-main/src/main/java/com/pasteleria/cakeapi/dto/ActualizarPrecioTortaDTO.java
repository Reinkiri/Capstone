package com.pasteleria.cakeapi.dto;

public class ActualizarPrecioTortaDTO {
    private Long tamanoId; // ID del TamanoTorta a modificar
    private Double nuevoPrecio;

    public ActualizarPrecioTortaDTO() {}

    public ActualizarPrecioTortaDTO(Long tamanoId, Double nuevoPrecio) {
        this.tamanoId = tamanoId;
        this.nuevoPrecio = nuevoPrecio;
    }

    public Long getTamanoId() {
        return tamanoId;
    }

    public void setTamanoId(Long tamanoId) {
        this.tamanoId = tamanoId;
    }

    public Double getNuevoPrecio() {
        return nuevoPrecio;
    }

    public void setNuevoPrecio(Double nuevoPrecio) {
        this.nuevoPrecio = nuevoPrecio;
    }
}