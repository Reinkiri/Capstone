package com.pasteleria.cakeapi.controllers;

import com.pasteleria.cakeapi.dto.FcmTokenDTO;
import com.pasteleria.cakeapi.entities.Usuario;
import com.pasteleria.cakeapi.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // 👑 ADMIN: Listar todos los perfiles de la empresa
    @GetMapping
    public ResponseEntity<List<Usuario>> listarUsuarios() {
        return ResponseEntity.ok(usuarioRepository.findAll());
    }

    // 👑 ADMIN: Crear nuevo perfil (Administrador, Trabajador o Cliente)
    @PostMapping("/crear")
    public ResponseEntity<?> crearUsuario(@RequestBody Usuario usuario) {
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        Usuario nuevo = usuarioRepository.save(usuario);
        return ResponseEntity.ok(nuevo);
    }

    // 👑 ADMIN: Eliminar un usuario/trabajador
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarUsuario(@PathVariable Long id) {
        usuarioRepository.deleteById(id);
        return ResponseEntity.ok("Usuario eliminado");
    }

    // 🔔 ACTUALIZAR TOKEN FCM PARA NOTIFICACIONES PUSH
    @PutMapping("/{id}/token-fcm")
    public ResponseEntity<?> actualizarFcmToken(@PathVariable Long id, @RequestBody FcmTokenDTO dto) {
        return usuarioRepository.findById(id).map(usuario -> {
            usuario.setFcmToken(dto.getFcmToken());
            usuarioRepository.save(usuario);
            return ResponseEntity.ok().body("Token FCM actualizado correctamente");
        }).orElse(ResponseEntity.notFound().build());
    }
}