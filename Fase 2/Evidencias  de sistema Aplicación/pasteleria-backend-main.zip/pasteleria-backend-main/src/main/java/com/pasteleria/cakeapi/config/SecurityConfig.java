package com.pasteleria.cakeapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable) // Desactivado CSRF para Flutter y Web
                .cors(Customizer.withDefaults()) // Habilita CORS para peticiones Web
                .authorizeHttpRequests(auth -> auth
                        // 🛍️ VISTA CLIENTE / PÚBLICA (Ver tortas, coberturas, agendar, editar, login y calendario)
                        .requestMatchers(HttpMethod.GET, "/api/tortas/**", "/api/coberturas/**", "/api/pedidos/mes", "/api/pedidos/fecha/**", "/api/dias-bloqueados/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/pedidos", "/api/dias-bloqueados").permitAll()
                        .requestMatchers(HttpMethod.PUT, "/api/pedidos/**").permitAll() // 👈 ¡AQUÍ ESTABA EL 403! Se permite editar pedidos.
                        .requestMatchers(HttpMethod.DELETE, "/api/pedidos/**", "/api/dias-bloqueados/**").permitAll()
                        .requestMatchers("/api/auth/**").permitAll() // Login/autenticación

                        // 🔔 NOTIFICACIONES FCM (Permite registrar el token sin ser bloqueado)
                        .requestMatchers(HttpMethod.PUT, "/api/usuarios/*/token-fcm").permitAll()

                        // 👨‍🍳 VISTA TRABAJADOR Y ADMIN (Escaneo de barras y cambio de estado en cocina)
                        .requestMatchers("/api/pedidos/escanear/**", "/api/pedidos/*/estado").hasAnyAuthority("ADMIN", "TRABAJADOR")

                        // 👑 VISTA ADMIN EXCLUSIVA (Precios, CRUD de tortas y usuarios)
                        .requestMatchers("/api/tortas/actualizar-precios").hasAuthority("ADMIN")
                        .requestMatchers(HttpMethod.POST, "/api/tortas/**").hasAuthority("ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/tortas/**").hasAuthority("ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/api/tortas/**").hasAuthority("ADMIN")
                        .requestMatchers("/api/usuarios/**").hasAuthority("ADMIN")

                        // Cualquier otra petición requiere autenticación por defecto
                        .anyRequest().authenticated()
                );
        return http.build();
    }

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}